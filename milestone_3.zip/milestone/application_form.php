<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Application Form</title>
    <link rel="stylesheet" href="application_form.css">
    <link rel="stylesheet" href="index.css">
   

</head>
<body>
<Header>
        <nav class="navigation_bar">
            <a href="http://ccse.kennesaw.edu/it"><img src="images/it.jpeg" alt="" height="50px" width="50px" class="logo"></a>
            <H1>Center For Applied Research in Information Technology (CARIT) </H1>
            <ul class="list_elements">
                <a href="index.php"><li>Home</li></a>
                <a href="aboutus.php"><li>About Us</li></a>
                <a href="projects.php"><li>Projects</li></a>
                <a href="opportunities.php"><li>opportunities</li></a>
            </ul>
        </nav>    
    </Header>
    <br>
    <h2>Student Application Form</h2>
    <form action="process_application.php" method="post">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required><br><br>

        <label for="phone_number">Phone Number:</label>
        <input type="text" id="phone_number" name="phone_number" pattern="\d{3}-\d{3}-\d{4}" title="Phone number must be in the format xxx-xxx-xxxx" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="address">Address:</label>
        <input type="text" id="address" name="address" required><br><br>

        <label for="state">State:</label>
        <input type="text" id="state" name="state" required><br><br>

        <label for="zipcode">Zipcode:</label>
        <input type="text" id="zipcode" name="zipcode" required><br><br>

        <label for="gender">Gender:</label>
        <input type="radio" id="male" name="gender" value="male" required>
        <label for="male">Male</label>
        <input type="radio" id="female" name="gender" value="female">
        <label for="female">Female</label><br><br>

        <label for="student status">Student Status:</label>
        <input type="radio" id="undergraduate" name="student status" value="undergraduate" required>
        <label for="undergraduate">Undergraduate</label>
        <input type="radio" id="graduate" name="student status" value="graduate">
        <label for="graduate">Graduate</label><br><br>

        <label for="starting semester">Starting Semester:</label>
        <input type="radio" id="Summer 2024" name="starting semester" value="Summer 2024" required>
        <label for="Summer 2024">Summer 2024</label>
        <input type="radio" id="Fall 2024" name="starting semester" value="Fall 2024">
        <label for="Fall 2024">Fall 2024</label>
        <input type="radio" id="Spring 2025" name="starting semester" value="Spring 2025">
        <label for="Spring 2025">Spring 2025</label><br><br>
        

        <label for="major">Major:</label>
        <select id="major" name="major" required>
            <option value="">Select</option>
            <option value="Computer Science">Computer Science</option>
            <option value="Information Technology">Information Technology</option>
            <option value="Data Science">Data Science</option>
            <option value="Cybersecurity">CyberSecurity</option>

        </select><br><br>

        <label for="interests">Interests:</label><br>
        <input type="checkbox" id="programming" name="interests[]" value="Programming">
        <label for="programming">Programming</label>
        <input type="checkbox" id="cybersecurity" name="interests[]" value="Cybersecurity">
        <label for="cybersecurity">Cybersecurity</label>
        <input type="checkbox" id="ai_ml" name="interests[]" value="AI/ML">
        <label for="ai_ml">AI/ML</label><br><br>

        <label for="comments">Comments:</label><br>
        <textarea id="comments" name="comments" rows="4" cols="50"></textarea><br><br>

        <input type="submit" value="Submit">
    </form>

    <div id="error-messages">
        <?php
        if (isset($_GET['success'])) {
            if ($_GET['success'] === 'false') {
                $errors = json_decode(urldecode($_GET['errors']));
                echo "<ul>";
                foreach ($errors as $error) {
                    echo "<li>$error</li>";
                }
                echo "</ul>";
            } elseif ($_GET['success'] === 'true') {
                echo "<p>Form submitted successfully!</p>";
            }
        }
        ?>
    </div>
    <script>
        document.getElementById('phone_number').addEventListener('input', function (event) {
            const phoneNumber = event.target.value.replace(/\D/g, ''); // Remove non-numeric characters
            const formattedPhoneNumber = formatPhoneNumber(phoneNumber);
            event.target.value = formattedPhoneNumber;
        });

        function formatPhoneNumber(phoneNumber) {
            const matched = phoneNumber.match(/^(\d{3})(\d{0,3})(\d{0,4})$/);
            if (matched) {
                return [matched[1], matched[2], matched[3]].filter(Boolean).join('-');
            }
            return phoneNumber;
        }
        
        document.getElementById('application-form').addEventListener('submit', function (event) {
            const form = event.target;
            let isValid = true;

            // Validate each input field
            Array.from(form.elements).forEach(element => {
                if (element.required && !element.value.trim()) {
                    isValid = false;
                    showError(element, `${getFieldName(element)} is required`);
                }
            });

            if (!isValid) {
                event.preventDefault(); // Prevent form submission if validation fails
            }
        });

        // Function to show error message
        function showError(element, message) {
            const errorDiv = document.createElement('div');
            errorDiv.className = 'error-message';
            errorDiv.textContent = message;
            element.parentNode.appendChild(errorDiv);
        }

        // Function to get field name for error message
        function getFieldName(element) {
            return element.labels[0].textContent;
        }
        
    </script>
<?php include 'footer.php'; ?>
</html>
