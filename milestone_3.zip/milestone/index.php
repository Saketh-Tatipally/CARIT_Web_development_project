<?php include 'header.php';?>
    <br>
    <div class="content">
        <div>
            <p>The Center for Applied Research in Information Technology (CARIT) is an innovative research institution dedicated to advancing the field of information technology through cutting-edge research, collaboration, and knowledge dissemination.</p>
        </div>
        <br>
        <h2>The Latest News Of the CARIT:</h2>       
    </div>
    <br>
    <ul>
        <li>1. CARIT Launches New Initiative to Combat Cybersecurity Threats: In collaboration with industry partners, CARIT has launched a new research initiative aimed at enhancing cybersecurity defenses against emerging threats. The initiative will focus on developing innovative techniques and tools to protect critical infrastructure and safeguard sensitive data.</li>
    </ul>
    <br>
    <br>
    <img src="images/cybersecurity.jpg" alt="" height="300px" width="250px" class="images">
    <br>
    <br>
    <br>
    <ul>
        <li>2. CARIT Researchers Receive Grant for AI-Powered Healthcare Project: A team of researchers at CARIT has been awarded a significant grant to develop AI-driven solutions for improving healthcare outcomes. The project will leverage advanced machine learning algorithms to analyze medical data and assist healthcare professionals in making more accurate diagnoses and treatment decisions.</li>
    </ul>
    <br>
    <img src="images/ai.png" alt="" height="300px" width="250px" class="images">
    <br>
    <br>
    <ul>
        <li>3. CARIT Hosts International Symposium on Big Data Analytics: CARIT recently hosted a successful symposium bringing together leading experts in big data analytics from around the world. The event featured keynote presentations, panel discussions, and research demonstrations showcasing the latest advancements in data science and analytics.</li>
    </ul>
    <br>
    <img src="images/ds.jpg" alt="" height="300px" width="250px" class="images">
    <br>
    <br>
    

    <script src="opportunities.js"></script>
    <?php include 'footer.php'; ?>

</html>