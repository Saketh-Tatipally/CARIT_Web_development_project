<?php include 'header.php'; ?>
    <br>
    <h2 style="text-align: center;">STUDENT EMPLOYEMENT OPPORTUNITIES AT THE CARIT</h2>
    <br>
    <img src="images/photo.jpg" alt="" height="300px" width="300px" class="images">
    <br>
    <br>
    <p>Summer 2024 is coming and the CARIT has FOUR Student Assistant Positions Open! Undergraduate Students may choose between CSE 3203 Mobile System Overview and IT 4213 Mobile Web Development. Graduate Students may choose between IT 7113 Data Visualization and IT 6713 Business Intelligence.In order to be considered for these opportunities, You must have had completed some required courses with an average grade requirement of a  GPA greater than 3.2 for undergraduate students and GPA greater than 3.7 for graduate students.  </p>
    <br>
    <br>
    <h3 style="text-align: center;" >PLEASE ANSWER THE FOLLOWING QUESTIONS TO VERIFY YOUR ELGIBILITY: </h3>
    <br>
    <br>
    <main>
        <section id="eligibility-form">
            <h2>Evaluate Your Eligibility</h2>
            <p>Fill out the form below to check if you are eligible to apply for the student assistant positions.</p>
            <form id="evaluation-form">
                <label for="student-status">Student Status:</label>
                <select id="student-status">
                    <option value="undergraduate">Undergraduate</option>
                    <option value="graduate">Graduate</option>
                </select><br><br>
                <div id="course-list">
                    <!-- Course options will be populated dynamically based on selected student status -->
                </div>
                <button type="button" id="evaluate-btn">Evaluate</button>
            </form>
            <div id="result"></div>
        </section>
    </main>
    
    <script src="opportunities.js"></script> <!-- Link to your JavaScript file -->
    <?php include 'footer.php'; ?>


    


</html>