document.addEventListener('DOMContentLoaded', function () {
    const undergraduateCourses = ["CSE 3203 Mobile System Overview", "IT 4213 Mobile Web Development"];
    const graduateCourses = ["IT 7113 Data Visualization", "IT 6713 Business Intelligence"];

    const studentStatusSelect = document.getElementById('student-status');
    const courseList = document.getElementById('course-list');
    const evaluateBtn = document.getElementById('evaluate-btn');
    const resultDiv = document.getElementById('result');

    studentStatusSelect.addEventListener('change', function () {
        const selectedStatus = studentStatusSelect.value;
        const courses = (selectedStatus === 'undergraduate') ? undergraduateCourses : graduateCourses;
        populateCourseInputs(courses);
    });

    function populateCourseInputs(courses) {
        courseList.innerHTML = ''; // Clear previous inputs
        courses.forEach(course => {
            const label = document.createElement('label');
            label.textContent = course + ': ';
            const input = document.createElement('input');
            input.type = 'text';
            input.name = course.replace(/\s/g, ''); // Remove spaces for input name
            input.classList.add('grade-input');
            input.placeholder = 'Enter grade (0-4)';
            courseList.appendChild(label);
            courseList.appendChild(input);
            courseList.appendChild(document.createElement('br'));
        });
    }

    function isValidGrade(grade) {
        return !isNaN(grade) && grade >= 0 && grade <= 4;
    }

    evaluateBtn.addEventListener('click', function () {
        const selectedStatus = studentStatusSelect.value;
        const courses = (selectedStatus === 'undergraduate') ? undergraduateCourses : graduateCourses;

        let totalGrade = 0;
        let totalCourses = 0;
        let invalidGrade = false; // Flag to track if any invalid grades are found

        courses.forEach(course => {
            const input = document.querySelector(`input[name='${course.replace(/\s/g, '')}']`);
            const courseGrade = parseFloat(input.value);
            if (isValidGrade(courseGrade)) {
                totalGrade += courseGrade;
                totalCourses++;
            } else {
                invalidGrade = true;
            }
        });

        if (invalidGrade) {
            resultDiv.innerHTML = `<p>Invalid grade entered. Please enter grades between 0 and 4.</p>`;
            return; // Exit the function if invalid grade is found
        }

        const averageGrade = totalGrade / totalCourses;
        let message;

        if (averageGrade >= (selectedStatus === 'undergraduate' ? 3.2 : 3.7)) {
            message = `Congratulations! You are eligible to apply for the student assistant position. `;
            message += 'Click <a href="application_form.php"> here </a> to apply.'; // Link to application page
        } else {
            message = `Thank you for your interest, but you do not meet the eligibility requirements.`;
        }

        resultDiv.innerHTML = `<p>Your average grade is: ${averageGrade.toFixed(2)}</p><p>${message}</p>`;
    });

    // Populate course inputs initially
    populateCourseInputs(undergraduateCourses);
});
