<footer>
        <a href="http://it5443.azurewebsites.net" target="_blank">NOTE: This a Class Project</a>
    </footer>
    </body>
