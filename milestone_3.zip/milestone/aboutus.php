<?php include 'header.php'; ?>
    <br>
    <div>
        <p>Our faculty members are experts in their respective fields, bringing a wealth of knowledge and experience to the CARIT community. With diverse backgrounds and expertise spanning areas such as computer science, data science, cybersecurity, artificial intelligence, and more, our faculty are committed to excellence in research, education, and mentorship.</p>
    </div>
    <br>
    <br>
    <div>
        <h2>Meet Our Faculty Members:</h2>
    </div>
    <section class="custom_card">
        <div class="cards">
            <a href="https://facultyweb.kennesaw.edu/swu10/index.php" target="blank"><img src="images/shaoen-wu.jpg" alt="" height="150px" width="150px"></a>
            <a href="https://facultyweb.kennesaw.edu/swu10/index.php"><h1>Shaoen Wu</h1></a>
            <h1>Chair of the Department of Information Technology and Professor of Information Technology</h1>
            <p>swu10@kennesaw.edu </p>
            <p>(470 578-3877)</p>
            <p> J 393B</p>
            <br>
            <p>Research Interests:  Cybersecurity, Internet of Things, Wireless Sensing and Networking, Smart Health</p>
        </div>
    
        <div class="cards">
            <a href="https://facultyweb.kennesaw.edu/xtian2/index.php"><img src="images/shirley-tian.jpg" alt="" height="150px" width="150px"></a>
            <a href="https://facultyweb.kennesaw.edu/xtian2/index.php"><h1>Shirley Tian</h1></a>
            <h1>MSIT Graduate Program Coordinator and Associate Professor of Information Technology</h1>
            <p>xtian2@kennesaw.edu</p>
            <p>(470) 578-5168</p>
            <p>J 378B</p>
            <br>
            <p>Research Interests:  Social Media Snalytics and Cybersecurity.
            </p>
        </div>
    
        <div class="cards">
            <a href="https://facultyweb.kennesaw.edu/lzhao10/index.php"><img src="images/liang-zhao1.png" alt="" height="150px" width="150px"></a>
            <a href="https://facultyweb.kennesaw.edu/lzhao10/index.php"><h1>Liang Zhao</h1></a>
            <h1>Assistant Professor of Information Technology</h1>
            <p>lzhao10@kennesaw.edu</p>
            <p>(470) 578-4902</p>
            <p>J 392</p>
            <br>
            <p>Research Interests: Cyber Security, Big Data Computing & Analytics, and Machine Learning.</p>
        </div>

    </section>  
    
    

    <script src="opportunities.js"></script>
    <?php include 'footer.php'; ?>

</html>