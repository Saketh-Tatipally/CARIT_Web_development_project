<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Submitted</title>
    <link rel="stylesheet" href="process_application.css">
    
</head>

<?php include 'header.php';?>
    <h1>Application Submitted</h1>
    <table>
        <tr>
            <th>Field</th>
            <th>Value</th>
        </tr>
        <tr>
            <td>Name</td>
            <td><?php echo isset($_POST['name']) ? $_POST['name'] : ''; ?></td>
        </tr>
        <tr>
            <td>Phone Number</td>
            <td><?php echo isset($_POST['phone_number']) ? $_POST['phone_number'] : ''; ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?></td>
        </tr>
        <tr>
            <td>Address</td>
            <td><?php echo isset($_POST['address']) ? $_POST['address'] : ''; ?></td>
        </tr>
        <tr>
            <td>State</td>
            <td><?php echo isset($_POST['state']) ? $_POST['state'] : ''; ?></td>
        </tr>
        <tr>
            <td>Zipcode</td>
            <td><?php echo isset($_POST['zipcode']) ? $_POST['zipcode'] : ''; ?></td>
        </tr>
        <tr>
            <td>Gender</td>
            <td><?php echo isset($_POST['gender']) ? $_POST['gender'] : ''; ?></td>
        </tr>
        <tr>
            <td>Student Status</td>
            <td><?php echo isset($_POST['student_status']) ? $_POST['student_status'] : ''; ?></td>
        </tr>
        <tr>
            <td>Starting Semester</td>
            <td><?php echo isset($_POST['starting_semester']) ? $_POST['starting_semester'] : ''; ?></td>
        </tr>
        <tr>
            <td>Major</td>
            <td><?php echo isset($_POST['major']) ? $_POST['major'] : ''; ?></td>
        </tr>
        <tr>
            <td>Interests</td>
            <td><?php echo isset($_POST['interests']) ? implode(', ', $_POST['interests']) : ''; ?></td>
        </tr>
        <tr>
            <td>Comments</td>
            <td><?php echo isset($_POST['comments']) ? $_POST['comments'] : ''; ?></td>
        </tr>
    </table>
    <?php include 'footer.php'; ?>

</html>
