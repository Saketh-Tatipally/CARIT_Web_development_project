<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CARIT-Home_Page</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <Header>
        <nav class="navigation_bar">
            <a href="http://ccse.kennesaw.edu/it"><img src="images/it.jpeg" alt="" height="50px" width="50px" class="logo"></a>
            <H1>Center For Applied Research in Information Technology (CARIT) </H1>
            <ul class="list_elements">
                <a href="index.php"><li>Home</li></a>
                <a href="aboutus.php"><li>About Us</li></a>
                <a href="projects.php"><li>Projects</li></a>
                <a href="opportunities.php"><li>opportunities</li></a>
            </ul>
        </nav>    
    </Header>